package jadex.micro.testcases.search;

public interface ITestService
{
}
