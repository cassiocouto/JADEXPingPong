package jadex.micro.testcases;


/**
 *
 */
public interface IBService
{
}
