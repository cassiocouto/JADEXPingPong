package jadex.micro.examples.hunterprey.service;

/**
 *  Root interface for percepts which can be observed by preys.
 */
public interface IPreyPerceivable
{
}
