package jadex.micro.testcases.parameterguesser;

/**
 *  Test service interface.
 */
public interface IInjectionTestService
{
	Object[] getInjectionClasses();

	Object[] getInjections();
}
