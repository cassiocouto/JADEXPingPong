package jadex.micro.testcases.configinheritance;

import jadex.micro.annotation.Agent;

@Agent
public class EmptyAAgent
{
}
