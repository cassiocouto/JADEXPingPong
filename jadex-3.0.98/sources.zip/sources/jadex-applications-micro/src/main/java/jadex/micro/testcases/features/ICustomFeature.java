package jadex.micro.testcases.features;

/**
 *  Test interface.
 */
public interface ICustomFeature 
{
	/**
	 *  Test method.
	 */
	public String someMethod();
}
