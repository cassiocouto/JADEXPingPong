package jadex.examples.docs;

import jadex.base.RootComponentConfiguration;

/**
 * Created by kalinowski on 29.09.16.
 */

public class Tools {
    private void rootconfig() {
        RootComponentConfiguration rootConfig = null;
        rootConfig.setGui(false);
    }
}
