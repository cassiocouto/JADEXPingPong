package jadex.examples.presentationtimer.common;

public interface ICountdownController {
	public void start();
	public void stop();
	public void reset();
}